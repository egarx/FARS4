
# FARS4

<!-- badges: start -->
<!-- badges: end -->

The goal of FARS4 is to ...

## Installation

You can install the released version of FARS4 from [CRAN](https://CRAN.R-project.org) with:

``` r
install.packages("FARS4")
```

## Example

This is a basic example which shows you how to solve a common problem:

``` r
library(FARS4)
## basic example code
```

